﻿using System;
using System.Diagnostics;
using System.IO;

namespace name
{
    class programm
    {
        static void Main(string[] args)
        {
            while (true)
            {


                int a;
                int b;

                Console.Clear();
                Console.ResetColor();
                Console.Write("Введите первое число ");

                a = int.Parse(Console.ReadLine());

                Console.Write("Введите второе число ");

                b = int.Parse(Console.ReadLine());

                switch (a)
                {
                    case 0:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Обнаружен 0 в первом числе!");
                        Console.ResetColor();
                        Console.Beep();
                        Console.Beep();
                        Console.Beep();
                        Console.Beep();
                        break;
                }

                switch (b)
                {
                    case 0:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Обнаружен 0 во втором числе, учтите, если вы будете делить первое число на ноль ничего хорошего не выйдет.");
                        Console.ResetColor();
                        Console.Beep();
                        Console.Beep();
                        Console.Beep();
                        Console.Beep();
                        break;
                }

                Console.Write("Введите операцию / * - + ");

                ConsoleKey consolekey = Console.ReadKey().Key;

                int result;

                switch (consolekey)
                {
                    case ConsoleKey.Multiply:
                        result = a * b;
                        Console.WriteLine(" Результат умножения: " + result);
                        break;

                    case ConsoleKey.Divide:
                        result = a / b;
                        Console.WriteLine(" Результат деления: " + result);
                        break;

                    case ConsoleKey.Add:
                        result = a + b;
                        Console.WriteLine(" Результат прибавления: " + result);
                        break;

                    case ConsoleKey.Subtract:
                        result = a - b;
                        Console.WriteLine(" Результат вычитания: " + result);
                        break;

                    default:
                        Console.Write(" - Неизвестная операция! ");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("(Вводите операции на Num PAD)");
                        Console.ResetColor();
                        break;

                }
                Console.Beep();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.ReadKey();
                continue;
            }
        }
    }
}